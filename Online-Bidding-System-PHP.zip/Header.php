
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#">Online-Auction</a>
        </div>
        <ul class="nav navbar-nav">
            <li><a href="UserProfile.php"><b>Profile</b></a></li>
            <li><a href="UserPost.php"><b>Add Post</b></a></li>
            <li><a href="MyPost.php"><b>MyPost</b></a></li>
            <li><a href="MyBid.php"><b>MyBid</b></a></li>
            <li><a href="Bidding.php"><b>Bidding</b></a></li>
            <!-- <li><a href="UNotification.php"><b>Notification</b></a></li> -->
        </ul>

        <ul class="nav navbar-nav navbar-right">
            <li><a href="ULogout.php"><span class="glyphicon glyphicon-user"></span> <b>Logout</b></a></li>
        </ul>
    </div>
</nav>