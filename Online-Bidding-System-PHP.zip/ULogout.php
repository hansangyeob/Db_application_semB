  <?php
  header("Location:Home.php");
  ?>