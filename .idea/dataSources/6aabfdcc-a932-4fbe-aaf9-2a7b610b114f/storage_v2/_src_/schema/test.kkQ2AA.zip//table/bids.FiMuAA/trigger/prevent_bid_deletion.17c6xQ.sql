create definer = root@localhost trigger prevent_bid_deletion
    before delete
    on bids
    for each row
begin
        IF OLD.b_id >= 1 THEN
            signal sqlstate '45000' set message_text = 'cannot delete';
        END IF;
    end;

