create
    definer = root@localhost function getBalance(iNum varchar(255)) returns decimal(8, 2)
begin
    declare bal decimal (8,2);
    set bal = null;

    select balance into bal
    from customer_account
    where i_num = iNum ;

    return bal;
end;

