create
    definer = root@localhost function sp_highest_offer_price(bid_price decimal(8, 2)) returns varchar(225)
BEGIN
declare i_num varchar(255);
    select bids.bidder into i_num
    from customer_account join bids
    where offer_price = (SELECT *
                       from bids
                       where offer_price = (select max(offer_price) from bids));
    return i_num;
end;

