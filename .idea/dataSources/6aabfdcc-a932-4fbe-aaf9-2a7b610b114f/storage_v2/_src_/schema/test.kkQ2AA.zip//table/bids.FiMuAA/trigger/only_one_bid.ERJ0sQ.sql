create definer = root@localhost trigger only_one_bid
    before insert
    on bids
    for each row
begin
        declare bidder_dup varchar(255);

        select count(b_id) into bidder_dup from bids where bidder= new.bidder;
        if bidder_dup > 0 then
            signal sqlstate '45000' set message_text = 'you can bid for only one product';
        end if ;
    end;

