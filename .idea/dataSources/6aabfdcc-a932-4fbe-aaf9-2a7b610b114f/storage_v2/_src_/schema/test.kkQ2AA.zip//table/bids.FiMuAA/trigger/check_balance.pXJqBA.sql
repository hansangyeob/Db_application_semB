create definer = root@localhost trigger check_balance
    before insert
    on bids
    for each row
begin
        declare current_max_price decimal;

        select current_price into current_max_price
        from auction_product
        where p_id = new.product_id;

        # check the offer_price > maximum current price
        if  current_max_price >= new.offer_price then
            signal sqlstate '45000' set message_text = 'cannot bid the product. check you offer price';
        end if ;

        # to check the 'bids.offer_price >= auction_product.price_min'
        if new.offer_price <= get_Min_Price(new.product_id) then
            signal sqlstate '45000' set message_text = 'you cannot offer lower price than minimum price';
        end if ;

        # check the customer_account.balance >= bids.offer_price,
        # (cannot insert higher bid price than balance)
        if new.offer_price > getBalance(new.bidder) then
            signal sqlstate '45000' set message_text = 'check your balance';
        end if ;
    end;

