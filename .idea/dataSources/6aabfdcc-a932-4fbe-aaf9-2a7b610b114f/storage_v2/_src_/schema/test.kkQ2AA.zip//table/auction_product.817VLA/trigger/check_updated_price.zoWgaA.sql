create definer = root@localhost trigger check_updated_price
    before update
    on auction_product
    for each row
begin
        if new.current_price < OLD.current_price then
            signal sqlstate '45000' set message_text = 'cannot update the current product price';
        end if ;
    end;

