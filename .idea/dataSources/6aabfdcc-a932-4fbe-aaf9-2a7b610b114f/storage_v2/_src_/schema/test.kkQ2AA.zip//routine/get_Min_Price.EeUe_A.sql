create
    definer = root@localhost function get_Min_Price(pid mediumint(8)) returns decimal
begin
    declare min decimal;

    select price_min into min
    from auction_product
    where pid = p_id;
    return min;
end;

