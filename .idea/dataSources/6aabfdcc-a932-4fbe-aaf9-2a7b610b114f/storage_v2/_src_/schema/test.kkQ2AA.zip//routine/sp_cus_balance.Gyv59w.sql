create
    definer = root@localhost procedure sp_cus_balance()
begin
    select i_num, balance, offer_price
    from customer_account join bids
    on i_num = bidder;
end;

